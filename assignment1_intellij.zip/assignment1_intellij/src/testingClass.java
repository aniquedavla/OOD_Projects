/**
 * Created by elmog on 2/22/2017.
 */
public class testingClass {
    public static void main(String[] args) {
        Bank bankTest = new Bank;

    }
}
