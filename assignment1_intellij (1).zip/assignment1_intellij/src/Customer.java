import java.util.ArrayList;

/**
 * Created by elmog on 2/22/2017.
 */
public class Customer {
    private ArrayList<CashCard> wallet; //contains list of cards customer have

    public Customer(ArrayList<CashCard> wallet) {
        this.wallet = wallet;
    }
}
